package md2html.html;

public class Paragraph extends  HtmlElement{
    private static final String  CODE = "p";

    public Paragraph() {
        this.tag =CODE;
    }
}
