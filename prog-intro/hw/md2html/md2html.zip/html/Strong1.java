package md2html.html;

public class Strong1 extends HtmlElement {
    private static final String CODE = "strong";
    public Strong1() {
        this.tag=CODE;
        this.markdownSize=2;
        this.offset=6;
    }
}
