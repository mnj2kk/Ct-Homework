package md2html.html;

public class Strong2 extends HtmlElement {
    private static final String CODE = "strong";
    public Strong2() {
        this.tag=CODE;
        this.markdownSize=2;
        this.offset=6;
    }
}
