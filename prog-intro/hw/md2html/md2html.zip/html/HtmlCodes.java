package md2html.html;

public class HtmlCodes {
    public static Strikeout STRIKEOUT = new Strikeout();
    public static Strong1 STRONG1 = new Strong1();
    public static Strong2 STRONG2 = new Strong2();
    public static Emphasis1 EMPHASIS1 = new Emphasis1();
    public static Emphasis2 EMPHASIS2 = new Emphasis2();
    public static Code CODE = new Code();
    public static Variable VARIABLE = new Variable("x");
}
